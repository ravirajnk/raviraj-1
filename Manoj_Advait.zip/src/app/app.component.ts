import { Component } from "@angular/core";

@Component({
  selector: "app-start",
  templateUrl: "./app.component.html",
  styleUrls: ["./app.component.css"]
})
export class FirstComponent {
  title = "Angular Welcomes You...!";
}
