import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-prod-one',
  templateUrl: './prod-one.component.html',
  styleUrls: ['./prod-one.component.css']
})
export class ProdOneComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
