export class MobParts {
  name: string;
  id: number;
  country: string;
  price: number;
  inStock: number;
  image: string;
  qntt: number;
}
