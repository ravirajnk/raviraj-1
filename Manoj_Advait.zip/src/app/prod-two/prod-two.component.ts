import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-prod-two',
  templateUrl: './prod-two.component.html',
  styleUrls: ['./prod-two.component.css']
})
export class ProdTwoComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
