import 'hammerjs';
import { platformBrowserDynamic } from "@angular/platform-browser-dynamic";
import { FirstModule } from "./app/app.module";

platformBrowserDynamic().bootstrapModule(FirstModule);
